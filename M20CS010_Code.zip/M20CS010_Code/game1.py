import pygame
import keyboard, random, time,numpy
import numpy as np 

BLACK = (0, 0, 0)
WHITE = (250, 250, 250)
WINDOW_HEIGHT = 400
WINDOW_WIDTH = 400




def hCost (cell_x,cell_y,dest_x,dest_y):
    return numpy.abs(cell_x-dest_x)+numpy.abs(cell_y-dest_y)

def goal():
    [goal.x,goal.y]=random.choice([(250,0),(300,0),(350,0),(300,50),(350,50),(250,100),(300,100),(350,100),(250,200),(350,200)])
    print(goal.x,goal.y)
    time.sleep(0.1)

def aStarAlgo(start_node, stop_node):
         
        open_set = set(start_node) 
        closed_set = set()
        agent_image = pygame.image.load(r'agent_50x50.png')

        g = {} #store distance from starting node
        parents = {}# parents contains an adjacency map of all nodes
 
        #ditance of starting node from itself is zero
        g[start_node] = 0
        #start_node is root node i.e it has no parent nodes
        #so start_node is set to its own parent node
        parents[start_node] = start_node
         
         
        while len(open_set) > 0:
            n = None
 
            #node with lowest f() is found
            for v in open_set:
                if n == None or g[v] + heuristic(v) < g[n] + heuristic(n):
                    n = v
            a=10
            for x in range (0,400,50):
                for y in range(0,400,50):
                     pygame.draw.rect(SCREEN, [0,100+a,255], pygame.Rect(x, y , 50, 50))
                     pygame.display.update()
                     time.sleep(0.01)
                     drawGrid()
                     pygame.display.update()
                a+=10

            if n == stop_node or Graph_nodes[n] == None:
                pass
            else:
                for (m, weight) in get_neighbors(n):
                    #nodes 'm' not in first and last set are added to first
                    #n is set its parent
                    if m not in open_set and m not in closed_set:
                        open_set.add(m)
                        parents[m] = n
                        g[m] = g[n] + weight
                         
     
                    #for each node m,compare its distance from start i.e g(m) to the
                    #from start through n node
                    else:
                        if g[m] > g[n] + weight:
                            #update g(m)
                            g[m] = g[n] + weight
                            #change parent of m to n
                            parents[m] = n
                             
                            #if m in closed set,remove and add to open
                            if m in closed_set:
                                closed_set.remove(m)
                                open_set.add(m)
 
            if n == None:
                print('Path does not exist!')
                return None
 
            # if the current node is the stop_node
            # then we begin reconstructin the path from it to the start_node
            if n == stop_node:
                path = []
 
                while parents[n] != n:
                    path.append(n)
                    n = parents[n]
                    

 
                path.append(start_node)
 
                path.reverse()

                
                
                print('Path found: {}'.format(path))
                count=0
                for p in path:
                    if p=='H8':
                        for q in range(50,400,50):
                            SCREEN.blit(agent_image, (q,350))
                            pygame.display.update()
                            time.sleep(.5)
                            count+=1
                        SCREEN.blit(agent_image, (350,150))
                        pygame.display.update()
                    if p=='F5':
                        for q in range(50,250,50):
                            SCREEN.blit(agent_image, (q,350))
                            pygame.display.update()
                            time.sleep(.5)
                            count+=1

                        for s in range(350,150,-50):
                            SCREEN.blit(agent_image, (250,s))
                            pygame.display.update()
                            time.sleep(.5)
                            count+=1
                    if p=='D2':
                        for q in range(50,150,50):
                             SCREEN.blit(agent_image, (q,350))
                             pygame.display.update()
                             time.sleep(.5)
                             count+=1
                        for r in range(350,0,-50):
                             SCREEN.blit(agent_image, (150,r))
                             pygame.display.update()
                             time.sleep(.5)
                             count+=1
                        SCREEN.blit(agent_image, (350,150))
                        pygame.display.update()
                    if p=='H3':
                        SCREEN.blit(agent_image, (350,100))
                        time.sleep(0.5)
                        pygame.display.update()
                        count+=1
                    if p=='H5':
                         SCREEN.blit(agent_image, (350,200))
                         time.sleep(0.5)
                         pygame.display.update()
                         count+=1
                    if p=='H2':
                         SCREEN.blit(agent_image, (350,50))
                         time.sleep(0.5)
                         pygame.display.update()
                         count+=1
                    if p=='H1':
                         SCREEN.blit(agent_image, (350,0))
                         time.sleep(0.5)
                         pygame.display.update()
                         count+=1
                    if p=='G3':
                         SCREEN.blit(agent_image, (300,100))
                         time.sleep(0.5)
                         pygame.display.update()
                         count+=1
                    if p=='G2':
                         SCREEN.blit(agent_image, (300,50))
                         time.sleep(0.5)
                         pygame.display.update()
                         count+=1
                    if p=='G1':
                         SCREEN.blit(agent_image, (300,0))
                         time.sleep(0.5)
                         pygame.display.update()
                         count+=1
                    if p=='F3':
                          for q in range(50,150,50):
                             SCREEN.blit(agent_image, (q,350))
                             pygame.display.update()
                             time.sleep(.5)
                             count+=1
                          for r in range(350,100,-50):
                             SCREEN.blit(agent_image, (150,r))
                             pygame.display.update()
                             time.sleep(.5)
                             count+=1
                          for s in range(150,300,50):
                             SCREEN.blit(agent_image,(s,100))
                             pygame.display.update()
                             time.sleep(.5)
                             count+=1
                    if p=='F1':
                         SCREEN.blit(agent_image, (250,0))
                         time.sleep(0.5)
                         pygame.display.update()
                         count+=1
                print("path cost:",count)
                return path

 
 
            # remove n from the open_list, and add it to closed_list
            # because all of his neighbors were inspected
            open_set.remove(n)
            closed_set.add(n)
 
        print('Path does not exist!')
        return None
         
#define fuction to return neighbor and its distance
#from the passed node
def get_neighbors(v):
    if v in Graph_nodes:
        return Graph_nodes[v]
    else:
        return None
#for simplicity we ll consider heuristic distances given
#and this function returns heuristic distance for all nodes
def heuristic(n):
        
        H_dist = {
            'A1': hCost(0, 0,goal.x,goal.y ),
            'A2': hCost(0, 50,goal.x,goal.y ),
            'A3': hCost(0, 100,goal.x,goal.y ),
            'A4': hCost(0, 150,goal.x,goal.y ),
            'A5': hCost(0, 200,goal.x,goal.y ),
            'A6': hCost(0, 250,goal.x,goal.y ),
            'A7': hCost(0, 300,goal.x,goal.y ),
            'S':15,
            
            'B1': hCost(50, 0,goal.x,goal.y ),
            'B2': hCost(50, 50,goal.x,goal.y ),
            'B3': hCost(50, 100,goal.x,goal.y ),
            'B4': hCost(50, 150,goal.x,goal.y ),
            'B5': hCost(50, 200,goal.x,goal.y ),
            'B6': hCost(50, 250,goal.x,goal.y ),
            'B7': hCost(50, 300,goal.x,goal.y ),
            'B8': hCost(50, 350,goal.x,goal.y ),
            
            'C1': hCost(100, 0,goal.x,goal.y ),
            'C2': hCost(100, 50,goal.x,goal.y ),
            'C3': hCost(100, 100,goal.x,goal.y ),
            'C4': hCost(100, 150,goal.x,goal.y ),
            'C5': hCost(100, 200,goal.x,goal.y ),
            'C6': hCost(100, 250,goal.x,goal.y ),
            'C7': hCost(100, 300,goal.x,goal.y ),
            'C8': hCost(100, 350,goal.x,goal.y ),
            
            'D1': hCost(150, 0,goal.x,goal.y ),
            'D2': hCost(150, 50,goal.x,goal.y ),
            'D3': hCost(150,100,goal.x,goal.y ),
            'D4': hCost(150, 150,goal.x,goal.y ),
            'D5': hCost(150, 200,goal.x,goal.y ),
            'D6': hCost(150, 250,goal.x,goal.y ),
            'D7': hCost(150, 300,goal.x,goal.y ),
            'D8': hCost(150, 350,goal.x,goal.y ),
            
            'E1': hCost(200, 0,goal.x,goal.y ),
            'E2': hCost(200, 50,goal.x,goal.y ),
            'E3': hCost(200, 100,goal.x,goal.y ),
            'E4': hCost(200, 150,goal.x,goal.y ),
            'E5': hCost(200, 200,goal.x,goal.y ),
            'E6': hCost(200, 250,goal.x,goal.y ),
            'E7': hCost(200, 300,goal.x,goal.y ),
            'E8': hCost(200, 350,goal.x,goal.y ),
            
            
            'F1': hCost(250, 0,goal.x,goal.y ),
            'F2': hCost(250, 50,goal.x,goal.y ),
            'F3': hCost(250, 100,goal.x,goal.y ),
            'F4': hCost(250, 150,goal.x,goal.y ),
            'F5': hCost(250, 200,goal.x,goal.y ),
            'F6': hCost(250, 250,goal.x,goal.y ),
            'F7': hCost(250, 300,goal.x,goal.y ),
            'F8': hCost(250, 350,goal.x,goal.y ),
            
            'G1': hCost(300, 0,goal.x,goal.y ),
            'G2': hCost(300, 50,goal.x,goal.y ),
            'G3': hCost(300, 100,goal.x,goal.y ),
            'G4': hCost(300, 150,goal.x,goal.y ),
            'G5': hCost(300, 200,goal.x,goal.y ),
            'G6': hCost(300, 250,goal.x,goal.y ),
            'G7': hCost(300, 300,goal.x,goal.y ),
            'G8': hCost(300, 350,goal.x,goal.y ),
            
            'H1': hCost(350, 0,goal.x,goal.y ),
            'H2': hCost(350, 50,goal.x,goal.y ),
            'H3': hCost(350, 100,goal.x,goal.y ),
            'H4': hCost(350, 150,goal.x,goal.y ),
            'H5': hCost(350, 200,goal.x,goal.y ),
            'H6': hCost(350, 250,goal.x,goal.y ),
            'H7': hCost(350, 300,goal.x,goal.y ),
            'H8': hCost(350, 350,goal.x,goal.y ),
            
        }
 
        return H_dist[n]
 
#Describe your graph here  
Graph_nodes = {
   
     'S': [('H8',8),('D2',8),('B3',9),('F5',8),('F3',10)],
    #'H4':  [('F1',5),('F3',3),('F5',3),('G1',4),('G2',3),('G3',2),('G5',3),('H1',3),('H3',1),('H5',1)],
    'H4': [('H5',1),('H3',1)],
    'H3': [('H2',1),('G3',1)],
    'H2': [('H1',1),('G2',1)],
    'H1': [('G1',1)],
    'G1': [('F1',1),('G2',1)],
    'G2': [('G3',1),('H2',1)],
    'G3': [('F3',1),('H3',1)],
    'D2': [('H4',1)],
    'F5': None,
    'F3': None,
    'B3': [('H4',1)],
    'H8': [('H4',1)],
    'H5': None,
    'F3':None,
    'F1':[('G1',1)]
    
    
    

    
     
}


def main():
    global SCREEN, CLOCK
    
    pygame.init()
    SCREEN = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    CLOCK = pygame.time.Clock()
    SCREEN.fill(WHITE)

    while True:
        if keyboard.is_pressed(' '): 
            SCREEN.fill(WHITE)
            pygame.display.update()
            goal()
            drawGrid()
            if [goal.x,goal.y]==[250,0]:
                aStarAlgo('S', 'E1')
            if [goal.x,goal.y]==[300,0]:
                aStarAlgo('S', 'G1')
            if [goal.x,goal.y]==[350,0]:
                aStarAlgo('S', 'H1')
            if [goal.x,goal.y]==[300,50]:
                aStarAlgo('S', 'G2')
            if [goal.x,goal.y]==[350,50]:
                aStarAlgo('S', 'H2')
            if [goal.x,goal.y]==[250,100]:
                aStarAlgo('S', 'F3')
            if [goal.x,goal.y]==[300,100]:
                aStarAlgo('S', 'G3')
            if [goal.x,goal.y]==[350,100]:
                aStarAlgo('S', 'H3')
            if [goal.x,goal.y]==[250,200]:
                aStarAlgo('S', 'F5')
            if [goal.x,goal.y]==[350,200]:
                aStarAlgo('S', 'H5')
            
            time.sleep(0.5)



            


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        pygame.display.update()


def drawGrid():
    blockSize = 50 #Set the size of the grid block
    color = (255,0,0)
    start_color=(0,0,255)
    #ball_pos=[(250,0),(300,0),(350,0),(300,50),(350,50),(250,100),(300,100),(350,100),(250,200),(350,200)] 
    restart_image = pygame.image.load(r'restart_50x50.png')
    power_image = pygame.image.load(r'power_50x50.jpg')
    goto_image = pygame.image.load(r'goto_50x50.png')
    ball_image = pygame.image.load(r'ball_50x50.png')
    agent_image = pygame.image.load(r'agent_50x50.png')

   
    for x in range(0, WINDOW_WIDTH, blockSize):
        for y in range(0, WINDOW_HEIGHT, blockSize):
            rect = pygame.Rect(x, y, blockSize, blockSize)
            pygame.draw.rect(SCREEN, BLACK, rect, 1)
    pygame.draw.rect(SCREEN, color, pygame.Rect(100, 0, 50, 200))
    pygame.draw.rect(SCREEN, color, pygame.Rect(50, 250, 100, 50))
    pygame.draw.rect(SCREEN, color, pygame.Rect(200, 50, 100, 50))
    pygame.draw.rect(SCREEN, color, pygame.Rect(200, 150, 50, 200)) 
    pygame.draw.rect(SCREEN, color, pygame.Rect(250, 150, 100, 50))
    pygame.draw.rect(SCREEN, color, pygame.Rect(300, 300, 100, 50))
    pygame.draw.rect(SCREEN, start_color, pygame.Rect(0, 350, 50, 50))
    SCREEN.blit(agent_image, (0, 350))
    SCREEN.blit(goto_image, (350, 350)) 
    SCREEN.blit(goto_image, (50, 100)) 
    SCREEN.blit(goto_image, (150, 50))
    SCREEN.blit(restart_image, (0, 200))
    SCREEN.blit(restart_image, (300, 200))
    SCREEN.blit(power_image, (350, 150))  
    
    SCREEN.blit(ball_image,(goal.x,goal.y))
    pygame.display.flip()



# reward matrix
reward = np.matrix([[0,0,0],
                    [0,1,100],
                    [1,0,0],
                    [0,0,-1],
                    [15,0,20]])

#memory matrix
memory = np.matrix(np.zeros([5,3]))
#gamma learning parameter
gamma=0.5

initial_state=1

def available_actions(state):
    current_state_row=reward[state]
    av_act = np.where(current_state_row >=0)[1]
    return av_act

available_act = available_actions(initial_state)

def sample_next_action(available_actions_range):
    next_action = int(np.random.choice(available_act,1))
    return next_action

action = sample_next_action(available_act)

#learning algo:memory matrix
def update(current_state, action, gamma):
    max_index = np.where(memory[action]== np.max(memory[action]))[1]

    if max_index.shape[0] > 1:
        max_index = int(np.random.choice(max_index, size=1))
    else:
        max_index=int(max_index)
    max_value = memory[action,max_index]

# LEARNING FORMULA
    memory[current_state,action] = reward[current_state,action] + gamma*max_value

#updating memory
update(initial_state, action, gamma)


#model training
for i in range(10000):
    current_state=np.random.randint(0,int(memory.shape[0]))
    available_act = available_actions(current_state)
    action = sample_next_action(available_act)
    update(current_state, action, gamma)
print("memory matrix:")
print(memory/np.max(memory)*100)




#model testing
current_state=3
steps =[current_state]
while current_state==5:
    next_step_index=np.where(memory[current_state]== np.max(memory[current_state]))[1]
    if next_step_index.shape[0] > 1:
        next_step_index = int(np.random.choice(next_step_index, size=1))
    else:
        next_step_index=int(next_step_index)
    
    steps.append(next_step_index)
    current_state=next_step_index


main()




